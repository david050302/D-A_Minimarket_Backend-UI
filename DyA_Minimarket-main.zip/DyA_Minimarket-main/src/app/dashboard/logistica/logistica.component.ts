import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
@Component({
  selector: 'app-logistica',
  imports: [RouterOutlet],
  templateUrl: './logistica.component.html',
  styleUrl: './logistica.component.css'
})
export class LogisticaComponent {

}
