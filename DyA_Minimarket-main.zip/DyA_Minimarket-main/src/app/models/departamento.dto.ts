
export interface DepartamentoDTO {
    id?: number;
    nombre: string;
}
