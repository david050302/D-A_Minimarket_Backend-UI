export interface UnidadDTO {
  id?: number;
  unidad: string;
  detalleUnidad: string;
}