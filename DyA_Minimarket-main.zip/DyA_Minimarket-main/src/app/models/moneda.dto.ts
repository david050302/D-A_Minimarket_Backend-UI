export interface MonedaDTO {
    id?: number;
    nombre?: string;
    detalle?: string;
}