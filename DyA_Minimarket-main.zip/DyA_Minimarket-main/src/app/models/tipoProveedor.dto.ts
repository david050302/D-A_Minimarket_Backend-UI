export interface TipoProveedorDTO {
  id?: number;
  nombre: string;
  detalle: string;
}