export interface RolDTO {
  id?: number;
  nombre: string;
  descripcion: string;
}
