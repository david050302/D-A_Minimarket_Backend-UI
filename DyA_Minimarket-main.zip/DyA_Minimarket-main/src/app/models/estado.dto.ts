export interface EstadoDTO {
  id?: number;
  estado?: string;
  detalleEstado?: string;
}