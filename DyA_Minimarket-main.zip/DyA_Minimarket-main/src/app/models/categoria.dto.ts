export interface CategoriaDTO {
  id?: number;
  nombreCategoria: string;
  detalleCategoria: string;
}