export interface FormaPagoDTO {
    id?: number;
    formaPago?: string;
    detalle?: string;
}